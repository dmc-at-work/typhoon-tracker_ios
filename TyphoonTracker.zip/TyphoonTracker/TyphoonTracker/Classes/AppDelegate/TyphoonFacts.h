//
//  TyphoonFacts.h
//  TyphoonTracker
//
//  Created by Mary Rose Oh on 10/8/14.
//  Copyright (c) 2014 Dungeon Innovations. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TyphoonFacts : NSObject

@property (strong, nonatomic) NSMutableArray *typhoonFactsArray;

-(NSString *) getFact;


@end
