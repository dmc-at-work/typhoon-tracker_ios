//
//  TyphoonTrackImageCell.h
//  TyphoonTracker
//
//  Created by Mary Rose Oh on 8/1/14.
//  Copyright (c) 2014 Dungeon Innovations. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TyphoonTrackImageCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *typhoonTrackMapImage;


@end
